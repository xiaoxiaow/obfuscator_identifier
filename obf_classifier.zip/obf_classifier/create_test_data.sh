python create_feature.py `pwd` $1
