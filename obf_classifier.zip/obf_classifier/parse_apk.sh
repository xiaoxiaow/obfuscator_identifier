bash run.sh  $1  none
